package com.android.objects;
	
public class AllStudent{
		
		String name;
		int user_id;
		public AllStudent(int user_id, String name){
			this.user_id = user_id;
			this.name = name;
		}
	
	}
	