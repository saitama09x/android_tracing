package com.android.model;

public class Score_img{
	
	public String user;
	public int img;
	public int score;
	public String date_created;
	public Score_img(String user, int img, int score, String date_created){
		this.user = user;
		this.img = img;
		this.score = score;
		this.date_created = date_created;
	}
	
}