package com.android.model;

public class AllStudent{
	
	public String name;
	public int user_id;
	public AllStudent(int user_id, String name){
		this.user_id = user_id;
		this.name = name;
	}
	
}