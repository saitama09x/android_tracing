package com.android.model;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import android.os.Handler;
import android.os.AsyncTask;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;


public class MysqlDB{
	
	public BufferedReader urlLink(String link, String data) throws Exception{
				URL url = new URL(link);
				URLConnection conn = url.openConnection(); 
				 
				conn.setDoOutput(true); 
				OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream()); 
				
				wr.write( data ); 
				wr.flush(); 
				
				BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				return reader;
	}
	
	public String userLogin(String uname, String pword, String type){			
		 try{				
				 String link="http://androidgradle.myartsonline.com/userLogin.php";
				 
				 String data  = URLEncoder.encode("user", "UTF-8") + "=" + URLEncoder.encode(uname, "UTF-8");
				 data += "&" + URLEncoder.encode("pass", "UTF-8") + "=" + URLEncoder.encode(pword, "UTF-8");
				 data += "&" + URLEncoder.encode("type", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8");
				
				StringBuilder sb = new StringBuilder();
				String line = null;
				BufferedReader reader = urlLink(link, data);
				
				while((line = reader.readLine()) != null)
				{
				   sb.append(line);
				   break;
				}
				 return sb.toString();
			 }catch(Exception ex){				 
					return new String("Exception: " + ex.getMessage());
			 }	
	}
	
	public String userSignIn(String fname, String lname, String uname, String pword, String type){
	try{		 
		 String link="http://androidgradle.myartsonline.com/signin.php";
		 String data  = URLEncoder.encode("fname", "UTF-8") + "=" + URLEncoder.encode(fname, "UTF-8");
		 data += "&" + URLEncoder.encode("lname", "UTF-8") + "=" + URLEncoder.encode(lname, "UTF-8");
		 data += "&" + URLEncoder.encode("uname", "UTF-8") + "=" + URLEncoder.encode(uname, "UTF-8");
	   	 data += "&" + URLEncoder.encode("pword", "UTF-8") + "=" + URLEncoder.encode(pword, "UTF-8");
		  data += "&" + URLEncoder.encode("type", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8");
		  
		StringBuilder sb = new StringBuilder();
		String line = null;
		BufferedReader reader = urlLink(link, data);			
			while((line = reader.readLine()) != null)
			{
			   sb.append(line);
			   break;
			}
			 return sb.toString();
		 }catch(Exception ex){				 
				return new String("Exception: " + ex.getMessage());
		 }	
		
	}
	
	public String userScore(String id, String cat, String score){
		try{
			String link="http://androidgradle.myartsonline.com/userScore.php";
			String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");
			data += "&" + URLEncoder.encode("cat", "UTF-8") + "=" + URLEncoder.encode(cat, "UTF-8");
			data += "&" + URLEncoder.encode("score", "UTF-8") + "=" + URLEncoder.encode(score, "UTF-8");			
		  
			StringBuilder sb = new StringBuilder();
			String line = null;
			BufferedReader reader = urlLink(link, data);			
			
			while((line = reader.readLine()) != null)
			{
			   sb.append(line);
			   break;
			}
			return sb.toString();
			
		}catch(Exception ex){
			return new String("Exception: " + ex.getMessage());
		}
	}
	
	public String displayScore(String id){
		try{
			String link="http://androidgradle.myartsonline.com/displayScore.php";
			String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");			
		  
			StringBuilder sb = new StringBuilder();
			String line = null;
			BufferedReader reader = urlLink(link, data);			
			
			while((line = reader.readLine()) != null)
			{
			   sb.append(line);
			   break;
			}
			return sb.toString();
			
		}catch(Exception ex){
			return new String("Exception: " + ex.getMessage());
		}
	}
	
	public String displaybycat(String id, String cat){
		try{
			String link="http://androidgradle.myartsonline.com/displaybycat.php";
			String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(id, "UTF-8");			
			data += "&" + URLEncoder.encode("cat", "UTF-8") + "=" + URLEncoder.encode(cat, "UTF-8");			
		  
			StringBuilder sb = new StringBuilder();
			String line = null;
			BufferedReader reader = urlLink(link, data);			
			
			while((line = reader.readLine()) != null)
			{
			   sb.append(line);
			   break;
			}
			return sb.toString();
			
		}catch(Exception ex){
			return new String("Exception: " + ex.getMessage());
		}
	}
	
	public String displayAllStudent(){
		try{
			String link="http://androidgradle.myartsonline.com/displayallStudent.php";
			String data  = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode("", "UTF-8");						
		  
			StringBuilder sb = new StringBuilder();
			String line = null;
			BufferedReader reader = urlLink(link, data);			
			
			while((line = reader.readLine()) != null)
			{
			   sb.append(line);
			   break;
			}
			return sb.toString();
			
		}catch(Exception ex){
			return new String("Exception: " + ex.getMessage());
		}
	}
	
	
}