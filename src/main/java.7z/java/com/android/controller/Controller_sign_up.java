package com.android.controller;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.*;
import android.content.Context;
import java.util.ArrayList;
import android.database.Cursor;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import java.util.List; 
import android.widget.Spinner;
import com.android.R;
import com.android.model.*;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;

//Mysql
import android.os.Handler;
import android.os.AsyncTask;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import android.graphics.Typeface;
public class Controller_sign_up extends Activity {
		private EditText fname, lname, uname, pword;
		private Button sign_btn, login_btn;
		private Spinner  sel_type, sel_connect;
		private TextView head_title;
		private Context con = this;
		private Db_sqlite db;
		private CheckBox online_chk, offline_chk, student_chk, teacher_chk;
		@Override
	    public void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.sign_up);
			
			db = new Db_sqlite(con);
			
			fname = (EditText) findViewById(R.id.fname);
			lname = (EditText) findViewById(R.id.lname);
			uname = (EditText) findViewById(R.id.uname);
			pword = (EditText) findViewById(R.id.pword);
			sign_btn = (Button) findViewById(R.id.sign_btn);
			login_btn = (Button) findViewById(R.id.login_btn);
			online_chk = (CheckBox) findViewById(R.id.online);
			offline_chk = (CheckBox) findViewById(R.id.offline);
			student_chk = (CheckBox) findViewById(R.id.student);
			teacher_chk = (CheckBox) findViewById(R.id.teacher);
			head_title = (TextView) findViewById(R.id.head_title);

			Typeface face = Typeface.createFromAsset(getAssets(), "font/monoalph.ttf");
			head_title.setTypeface(face);
			
			/*
			sel_type = (Spinner) findViewById(R.id.sel_type);
			sel_connect = (Spinner) findViewById(R.id.sel_connect);
			*/
			/*
			List<String> type = new ArrayList<String>();
			type.add("STUDENT");
			type.add("TEACHER");
			
			List<String> type_connect = new ArrayList<String>();
			type_connect.add("ONLINE");
			type_connect.add("OFFLINE");
			
			ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, type);			
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);            
			sel_type.setAdapter(dataAdapter);
			
			ArrayAdapter<String> connect_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, type_connect);			
			connect_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);            
			sel_connect.setAdapter(connect_adapter);					
			*/
		}
		
		public void online_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			offline_chk.setChecked(false);	
			Controller_login.connect_type = "ONLINE";		
		}
	}

	public void offline_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			online_chk.setChecked(false);
			Controller_login.connect_type = "OFFLINE";		
		}
	}

	public void student_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			teacher_chk.setChecked(false);
			Controller_login.loginType = "STUDENT";
		}
	}

	public void teacher_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			student_chk.setChecked(false);
			Controller_login.loginType = "TEACHER";
		}
	}

		public void sign_new_account(View view){			
			if(Controller_login.connect_type.equals("ONLINE")){
				new MysqlSignUp(con, fname.getText().toString(), lname.getText().toString())
				.execute(fname.getText().toString(), lname.getText().toString(), 
				uname.getText().toString() ,pword.getText().toString(), Controller_login.loginType);																			
			}else{
				db.addUser(fname.getText().toString(), lname.getText().toString(), 
				uname.getText().toString(), pword.getText().toString());
				db.addType(Controller_login.loginType, uname.getText().toString());						
				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(con);			
				alertDialogBuilder.setTitle("Thank you for registration ");
				alertDialogBuilder.setMessage("Welcome " + fname.getText().toString() + " " + lname.getText().toString())					
				.setPositiveButton("Login",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						Intent goToNextActivity = new Intent(getApplicationContext(), Controller_login.class);
						finish();
						startActivity(goToNextActivity);
					}
				  });
				AlertDialog alertDialog = alertDialogBuilder.create();
				alertDialog.show();					
			}						
		}
		
		
	public void login_page(View view){		
		Intent goToNextActivity = new Intent(getApplicationContext(), Controller_login.class);
		finish();
		startActivity(goToNextActivity);		
	}
		
		class MysqlSignUp  extends AsyncTask<String,Void, String>{	

		private Context context;
		private EditText result;
		private String fname, lname;		
		private MysqlDB mysql;
		
		public MysqlSignUp(Context context, String fname, String lname) {
			  this.context = context;			 			  
			  this.fname = fname;
			  this.lname = lname;
		   }
		   
		 protected void onPreExecute()  {
			 mysql = new MysqlDB();
		 }
		   
		 protected String doInBackground(String... args)  {
				return mysql.userSignIn(args[0], args[1], args[2], args[3], args[4]);
		 }
		 
		  @Override
		   protected void onPostExecute(String data){
				if(data.equals("1")){
					AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(con);			
					alertDialogBuilder.setTitle("Thank you for registration ");
					alertDialogBuilder.setMessage("Welcome " + fname + " " + lname)					
					.setPositiveButton("Login",new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int id) {
						Intent goToNextActivity = new Intent(getApplicationContext(), Controller_login.class);
						finish();
						startActivity(goToNextActivity);
					}
				  });
					AlertDialog alertDialog = alertDialogBuilder.create();
					alertDialog.show();		
				}				
		   }
		   		  
	}
	
		
	
}