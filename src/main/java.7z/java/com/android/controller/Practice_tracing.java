package com.android.controller;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.*;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.app.Activity;
import android.view.*;
import android.widget.*;
import android.view.View.OnTouchListener;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import com.android.controller.evaluation.*;
import com.android.model.*;
import com.android.R;
import com.android.tracing.*;
import java.util.*;
import android.content.SharedPreferences;
import android.speech.tts.TextToSpeech;
import android.view.ViewGroup.LayoutParams;
//Mysql
import android.os.Handler;
import android.os.AsyncTask;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.graphics.Typeface;

public class Practice_tracing extends Activity {
	
	 private MediaPlayer big_letter_a, write_big_letter_a;
	 private Context con = this;
	 public static ArrayList score_arr = new ArrayList();	 
	 public static int total_score = 0;
	 public static int user_score = 0;
	 public static boolean wrong_trace = false;	 
	 public static String category_type = "big_a";
	 public static String category_letters = "big_a";
	 public static String tracing_type = "practice";
	 private double position_x = 0;	 
	 public static Db_sqlite db;	 
	 private Button done_btn, next_btn, retry_btn;
	 private Dialog next_diag;	 
	 private HashMap<String, String> letter_map_prev = new HashMap<String, String>();
	 private HashMap<String, String> letter_map_next = new HashMap<String, String>();
	 private int user_id = Controller_login.global_user_id;
	 public static List<Double> list_pixel_x = new ArrayList<Double>();
	 public static List<Double> list_pixel_y = new ArrayList<Double>();	
	 private HashMap<String, int[]> num_grid_map = new HashMap<String, int[]>();
	 private HashMap<String, int[]> wrong_grid_map = new HashMap<String, int[]>();
	 private HashMap<String, String> speak_text = new HashMap<String, String>();
	 private int[] right_tracing;
	 private int[] wrong_tracing;
	 private Grid_list grid;
	 private Tracing_algorithm tracing_alg_1, tracing_alg_2, tracing_alg_3;
	 private TextToSpeech speak_letter;
	 private HashMap<String, Integer> voice_speak = new HashMap<String, Integer>();
	 private MediaPlayer voice_big_letter, voice_letter;
	 private TextView letter_ah;
	 private ImageView logo_a;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);	

        //Call GUI layout from res/layout 									
		setContentView(R.layout.letter_practice);						
		Configuration config = getResources().getConfiguration();

		int scale_width = 170;
		if (config.smallestScreenWidthDp >= 600) {
			scale_width = 300;				
		}
		
		letter_ah = (TextView) findViewById(R.id.letter_ah);
		logo_a = (ImageView) findViewById(R.id.logo_a);

		Evaluation.eval_type = "intro";

		grid = new Grid_list();	
		this.init_objects();

		right_tracing = Arrays.copyOf(grid.get_rightgrid(Practice_tracing.category_type), 
			grid.get_rightgrid(Practice_tracing.category_type).length);

		wrong_tracing = Arrays.copyOf(grid.get_wronggrid(Practice_tracing.category_type), 
			grid.get_wronggrid(Practice_tracing.category_type).length);		

		num_grid_map.put(Practice_tracing.category_type, right_tracing);
		wrong_grid_map.put(Practice_tracing.category_type, wrong_tracing);

		tracing_alg_1 = new Tracing_algorithm(getApplicationContext()); 		
		tracing_alg_2 = new Tracing_algorithm(getApplicationContext());
		tracing_alg_3 = new Tracing_algorithm(getApplicationContext());

		LinearLayout linear_parent = new LinearLayout(getApplicationContext());
		float scale = tracing_alg_1.getContext().getResources().getDisplayMetrics().density;
		int pixels = (int) (scale_width * scale + 0.5f);
		RelativeLayout write_letter = (RelativeLayout) findViewById(R.id.write_letter);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(pixels, ViewGroup.LayoutParams.WRAP_CONTENT);
		
		if(Practice_tracing.tracing_type == "practice"){						
			lp.setMargins(0, 0, 20, 0);
			linear_parent.setOrientation(LinearLayout.HORIZONTAL);
			linear_parent.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

			if(Practice_tracing.category_letters == "small_a" || 
				Practice_tracing.category_letters == "small_i" || 
				Practice_tracing.category_letters == "small_r"){
				
				RelativeLayout.LayoutParams relparams = new RelativeLayout.LayoutParams(LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
				relparams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
				linear_parent.setLayoutParams(relparams);
				pixels = (int) (150 * scale + 0.5f);
				lp = new LinearLayout.LayoutParams(pixels, pixels);				

				if(Practice_tracing.category_type.equals("small_b") || 
					Practice_tracing.category_type.equals("small_d") || 
					Practice_tracing.category_type.equals("small_f") || 
					Practice_tracing.category_type.equals("small_k") || 
					Practice_tracing.category_type.equals("small_l") || 
					Practice_tracing.category_type.equals("small_t")){
					pixels = (int) (scale_width * scale + 0.5f);
					lp = new LinearLayout.LayoutParams(pixels, ViewGroup.LayoutParams.WRAP_CONTENT);
				}

			}

			
			if(!Practice_tracing.category_type.equals("rectangle")){
				tracing_alg_1.setLayoutParams(lp); 				
				tracing_alg_2.setLayoutParams(lp);
				tracing_alg_3.setLayoutParams(lp);
				linear_parent.addView(tracing_alg_1);
				linear_parent.addView(tracing_alg_2);
				linear_parent.addView(tracing_alg_3);
			}else{
				pixels = (int) (400 * scale + 0.5f);
				lp = new LinearLayout.LayoutParams(pixels, ViewGroup.LayoutParams.WRAP_CONTENT);
				tracing_alg_1.setLayoutParams(lp); 				
				tracing_alg_2.setLayoutParams(lp);
				linear_parent.addView(tracing_alg_1);
				linear_parent.addView(tracing_alg_2);
			}			
			linear_parent.setGravity(Gravity.CENTER_HORIZONTAL);
			write_letter.addView(linear_parent);
		}else{				
			tracing_alg_1.setLayoutParams(lp);
			linear_parent.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)); 				
			linear_parent.setBackground(getResources().getDrawable(R.drawable.rectbg));
			linear_parent.addView(tracing_alg_1);
			write_letter.addView(linear_parent);
		}

		speak_letter = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
	         @Override
	         public void onInit(int status) {
	            if(status != TextToSpeech.ERROR) {	            	
	               speak_letter.setLanguage(Locale.UK);	               
	               speak_letter.setSpeechRate(0.8f);
	               speak_letter.setPitch(0.7f);
	            }
	         }
      	});
		
		db = new Db_sqlite(con);
		
		next_diag = new Dialog(con);
		next_diag.requestWindowFeature(Window.FEATURE_NO_TITLE);
		next_diag.setContentView(R.layout.nextdialog);				
		done_btn = (Button) next_diag.findViewById(R.id.done_btn);		
		next_btn = (Button) next_diag.findViewById(R.id.next_image);
		retry_btn = (Button) next_diag.findViewById(R.id.retry_btn);

		retry_btn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
					retry_tracing(view);
			}
		});

		done_btn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
					done_tracing(view);
			}
		});
		
		next_btn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {
					next_tracing(view);					
			}
		});
				

    }

    public void init_objects(){

    	if(Practice_tracing.category_letters == "big_a"){
			letter_ah.setText("A-H");

			//Previous letters
			letter_map_prev.put("big_a", "big_h");
			letter_map_prev.put("big_b", "big_a");
			letter_map_prev.put("big_c", "big_b");
			letter_map_prev.put("big_d", "big_c");
			letter_map_prev.put("big_e", "big_d");
			letter_map_prev.put("big_f", "big_e");
			letter_map_prev.put("big_g", "big_f");
			letter_map_prev.put("big_h", "big_g");

			//next letters
			letter_map_next.put("big_a", "big_b");
			letter_map_next.put("big_b", "big_c");
			letter_map_next.put("big_c", "big_d");
			letter_map_next.put("big_d", "big_e");
			letter_map_next.put("big_e", "big_f");
			letter_map_next.put("big_f", "big_g");
			letter_map_next.put("big_g", "big_h");
			letter_map_next.put("big_h", "big_a");

			voice_big_letter = MediaPlayer.create(this, R.raw.write_big_letter);
			voice_speak.put("big_a", R.raw.letter_a);
			voice_speak.put("big_b", R.raw.letter_b);
			voice_speak.put("big_c", R.raw.letter_c);
			voice_speak.put("big_d", R.raw.letter_d);
			voice_speak.put("big_e", R.raw.letter_e);
			voice_speak.put("big_f", R.raw.letter_f);
			voice_speak.put("big_g", R.raw.letter_g);
			voice_speak.put("big_h", R.raw.letter_h);
		}

		if(Practice_tracing.category_letters == "big_i"){
			letter_ah.setText("I-Q");	
			letter_map_prev.put("big_i", "big_q");
			letter_map_prev.put("big_j", "big_i");
			letter_map_prev.put("big_k", "big_j");
			letter_map_prev.put("big_l", "big_k");
			letter_map_prev.put("big_m", "big_l");
			letter_map_prev.put("big_n", "big_m");
			letter_map_prev.put("big_o", "big_n");
			letter_map_prev.put("big_p", "big_o");
			letter_map_prev.put("big_q", "big_p");
			//next letters
			letter_map_next.put("big_i", "big_j");
			letter_map_next.put("big_j", "big_k");
			letter_map_next.put("big_k", "big_l");
			letter_map_next.put("big_l", "big_m");
			letter_map_next.put("big_m", "big_n");
			letter_map_next.put("big_n", "big_o");
			letter_map_next.put("big_o", "big_p");
			letter_map_next.put("big_p", "big_q");
			letter_map_next.put("big_q", "big_i");			

			voice_big_letter = MediaPlayer.create(this, R.raw.write_big_letter);			
			voice_speak.put("big_i", R.raw.letter_i);
			voice_speak.put("big_j", R.raw.letter_j);
			voice_speak.put("big_k", R.raw.letter_k);
			voice_speak.put("big_l", R.raw.letter_l);
			voice_speak.put("big_m", R.raw.letter_m);
			voice_speak.put("big_n", R.raw.letter_n);
			voice_speak.put("big_o", R.raw.letter_o);
			voice_speak.put("big_p", R.raw.letter_p);
			voice_speak.put("big_q", R.raw.letter_q);
		}

		if(Practice_tracing.category_letters == "big_r"){
			letter_ah.setText("R-Z");	
			letter_map_prev.put("big_z", "big_y");
			letter_map_prev.put("big_y", "big_x");
			letter_map_prev.put("big_x", "big_w");
			letter_map_prev.put("big_w", "big_v");
			letter_map_prev.put("big_v", "big_u");
			letter_map_prev.put("big_u", "big_t");
			letter_map_prev.put("big_t", "big_s");
			letter_map_prev.put("big_s", "big_r");
			letter_map_prev.put("big_r", "big_z");

			letter_map_next.put("big_r", "big_s");
			letter_map_next.put("big_s", "big_t");
			letter_map_next.put("big_t", "big_u");
			letter_map_next.put("big_u", "big_v");
			letter_map_next.put("big_v", "big_w");
			letter_map_next.put("big_w", "big_x");
			letter_map_next.put("big_x", "big_y");
			letter_map_next.put("big_y", "big_z");
			letter_map_next.put("big_z", "big_r");

			voice_big_letter = MediaPlayer.create(this, R.raw.write_big_letter);			
			voice_speak.put("big_r", R.raw.letter_r);
			voice_speak.put("big_s", R.raw.letter_s);
			voice_speak.put("big_t", R.raw.letter_t);
			voice_speak.put("big_u", R.raw.letter_u);
			voice_speak.put("big_v", R.raw.letter_v);
			voice_speak.put("big_w", R.raw.letter_w);
			voice_speak.put("big_x", R.raw.letter_x);
			voice_speak.put("big_y", R.raw.letter_y);
			voice_speak.put("big_z", R.raw.letter_z);
		}

		if(Practice_tracing.category_letters == "small_a"){
			letter_ah.setText("a-h");
			letter_map_prev.put("small_a", "small_h");
			letter_map_prev.put("small_b", "small_a");
			letter_map_prev.put("small_c", "small_b");
			letter_map_prev.put("small_d", "small_c");
			letter_map_prev.put("small_e", "small_d");
			letter_map_prev.put("small_f", "small_e");
			letter_map_prev.put("small_g", "small_f");
			letter_map_prev.put("small_h", "small_g");

			letter_map_next.put("small_a", "small_b");
			letter_map_next.put("small_b", "small_c");
			letter_map_next.put("small_c", "small_d");
			letter_map_next.put("small_d", "small_e");
			letter_map_next.put("small_e", "small_f");
			letter_map_next.put("small_f", "small_g");
			letter_map_next.put("small_g", "small_h");
			letter_map_next.put("small_h", "small_a");

			voice_big_letter = MediaPlayer.create(this, R.raw.write_small_letter);
			voice_speak.put("small_a", R.raw.letter_a);
			voice_speak.put("small_b", R.raw.letter_b);
			voice_speak.put("small_c", R.raw.letter_c);
			voice_speak.put("small_d", R.raw.letter_d);
			voice_speak.put("small_e", R.raw.letter_e);
			voice_speak.put("small_f", R.raw.letter_f);
			voice_speak.put("small_g", R.raw.letter_g);
			voice_speak.put("small_h", R.raw.letter_h);		
		}

		if(Practice_tracing.category_letters == "small_i"){
			letter_ah.setText("i-q");
			letter_map_prev.put("small_i", "small_q");
			letter_map_prev.put("small_j", "small_i");
			letter_map_prev.put("small_k", "small_j");
			letter_map_prev.put("small_l", "small_k");
			letter_map_prev.put("small_m", "small_l");
			letter_map_prev.put("small_n", "small_m");
			letter_map_prev.put("small_o", "small_n");
			letter_map_prev.put("small_p", "small_o");
			letter_map_prev.put("small_q", "small_p");

			//next letters
			letter_map_next.put("small_i", "small_j");
			letter_map_next.put("small_j", "small_k");
			letter_map_next.put("small_k", "small_l");
			letter_map_next.put("small_l", "small_m");
			letter_map_next.put("small_m", "small_n");
			letter_map_next.put("small_n", "small_o");
			letter_map_next.put("small_o", "small_p");
			letter_map_next.put("small_p", "small_q");
			letter_map_next.put("small_q", "small_i");

			voice_big_letter = MediaPlayer.create(this, R.raw.write_small_letter);
			voice_speak.put("small_i", R.raw.letter_i);
			voice_speak.put("small_j", R.raw.letter_j);
			voice_speak.put("small_k", R.raw.letter_k);
			voice_speak.put("small_l", R.raw.letter_l);
			voice_speak.put("small_m", R.raw.letter_m);
			voice_speak.put("small_n", R.raw.letter_n);
			voice_speak.put("small_o", R.raw.letter_o);
			voice_speak.put("small_p", R.raw.letter_p);
			voice_speak.put("small_q", R.raw.letter_q);

		}

		if(Practice_tracing.category_letters == "small_r"){
			letter_ah.setText("r-z");
			letter_map_prev.put("small_z", "small_y");
			letter_map_prev.put("small_y", "small_x");
			letter_map_prev.put("small_x", "small_w");
			letter_map_prev.put("small_w", "small_v");
			letter_map_prev.put("small_v", "small_u");
			letter_map_prev.put("small_u", "small_t");
			letter_map_prev.put("small_t", "small_s");
			letter_map_prev.put("small_s", "small_r");
			letter_map_prev.put("small_r", "small_z");

			letter_map_next.put("small_r", "small_s");
			letter_map_next.put("small_s", "small_t");
			letter_map_next.put("small_t", "small_u");
			letter_map_next.put("small_u", "small_v");
			letter_map_next.put("small_v", "small_w");
			letter_map_next.put("small_w", "small_x");
			letter_map_next.put("small_x", "small_y");
			letter_map_next.put("small_y", "small_z");
			letter_map_next.put("small_z", "small_r");

			voice_big_letter = MediaPlayer.create(this, R.raw.write_small_letter);			
			voice_speak.put("small_r", R.raw.letter_r);
			voice_speak.put("small_s", R.raw.letter_s);
			voice_speak.put("small_t", R.raw.letter_t);
			voice_speak.put("small_u", R.raw.letter_u);
			voice_speak.put("small_v", R.raw.letter_v);
			voice_speak.put("small_w", R.raw.letter_w);
			voice_speak.put("small_x", R.raw.letter_x);
			voice_speak.put("small_y", R.raw.letter_y);
			voice_speak.put("small_z", R.raw.letter_z);

		}

		if(Practice_tracing.category_letters == "shapes"){
			letter_ah.setText("");
			logo_a.setVisibility(View.GONE);
			letter_map_next.put("circle", "diamond");	
			letter_map_next.put("diamond", "rectangle");	
			letter_map_next.put("rectangle", "star");
			letter_map_next.put("star", "triangle");
			letter_map_next.put("triangle", "square");
			letter_map_next.put("square", "circle");

			letter_map_prev.put("circle", "triangle");	
			letter_map_prev.put("triangle", "star");	
			letter_map_prev.put("star", "rectangle");
			letter_map_prev.put("rectangle", "diamond");
			letter_map_prev.put("diamond", "square");
			letter_map_prev.put("square", "circle");

			voice_big_letter = MediaPlayer.create(this, R.raw.draw_a);
			voice_speak.put("circle", R.raw.circle);
			voice_speak.put("triangle", R.raw.triangle);
			voice_speak.put("star", R.raw.letter_c);
			voice_speak.put("rectangle", R.raw.rectangle);
			voice_speak.put("diamond", R.raw.letter_e);
			voice_speak.put("square", R.raw.square);
			
		}

		if(Practice_tracing.category_letters == "numbers"){
			letter_ah.setText("0-9");
			letter_map_prev.put("number_9", "number_8");	
			letter_map_prev.put("number_8", "number_7");	
			letter_map_prev.put("number_7", "number_6");	
			letter_map_prev.put("number_6", "number_5");	
			letter_map_prev.put("number_5", "number_4");	
			letter_map_prev.put("number_4", "number_3");	
			letter_map_prev.put("number_3", "number_2");	
			letter_map_prev.put("number_2", "number_1");	
			letter_map_prev.put("number_1", "number_0");
			letter_map_prev.put("number_0", "number_9");
			
			letter_map_next.put("number_0", "number_1");	
			letter_map_next.put("number_1", "number_2");	
			letter_map_next.put("number_2", "number_3");
			letter_map_next.put("number_3", "number_4");
			letter_map_next.put("number_4", "number_5");
			letter_map_next.put("number_5", "number_6");
			letter_map_next.put("number_6", "number_7");
			letter_map_next.put("number_7", "number_8");
			letter_map_next.put("number_8", "number_9");
			letter_map_next.put("number_9", "number_0");

			voice_big_letter = MediaPlayer.create(this, R.raw.draw_a);
			voice_speak.put("number_0", R.raw.circle);
			voice_speak.put("number_1", R.raw.triangle);
			voice_speak.put("number_2", R.raw.letter_c);
			voice_speak.put("number_3", R.raw.rectangle);			
			voice_speak.put("number_4", R.raw.rectangle);
			voice_speak.put("number_5", R.raw.rectangle);
			voice_speak.put("number_6", R.raw.rectangle);
			voice_speak.put("number_7", R.raw.rectangle);
			voice_speak.put("number_8", R.raw.rectangle);
			voice_speak.put("number_9", R.raw.rectangle);
			
		}

		voice_letter = MediaPlayer.create(this, voice_speak.get(Practice_tracing.category_type));
		voice_big_letter.setVolume(100f, 100f);
		voice_letter.setVolume(100f, 100f);
		voice_big_letter.setNextMediaPlayer(voice_letter);
		if(Practice_tracing.tracing_type.equals("voice")){
			if(MainSettings.set_vol){
				voice_big_letter.start();
			}
		}

    }
	
	public void voice_write_letter_a(View view){
			//write_big_letter_a.start();
			//String toSpeak = new String(speak_text.get(Practice_tracing.category_type)); 			           
            //speak_letter.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);						
			voice_letter = MediaPlayer.create(this, voice_speak.get(Practice_tracing.category_type));
			voice_big_letter.setVolume(100f, 100f);
			voice_letter.setVolume(100f, 100f);
			voice_big_letter.setNextMediaPlayer(voice_letter);
			if(MainSettings.set_vol){
				voice_big_letter.start();
			}				
	}
	
	public void voice_big_letter_a(View view){
			big_letter_a.start();
	}
	
	public void refresh_page(View view){			
			Intent refresh = new Intent(getApplicationContext(), Practice_tracing.class);
			finish(); 
			startActivity(refresh);		
	}

	public void home_page(View view){
			Intent refresh = new Intent(getApplicationContext(), HomePage.class);
			finish(); 
			startActivity(refresh);	
	}

	public void go_category(View view){
			Intent refresh = new Intent(getApplicationContext(), CategoryPage.class);
			finish(); 
			startActivity(refresh);	
	}

	public void onPause(){
      if(speak_letter !=null){
         speak_letter.stop();
         speak_letter.shutdown();
      }
      super.onPause();
   	}
	
	public void check_play(View view){
		
		if(Practice_tracing.tracing_type == "practice"){
			score_practice();			
		}else if(Practice_tracing.tracing_type == "voice"){
			if(Controller_login.connect_type.equals("ONLINE")){
				score_mysql();
			}else{
				score_voice();
			}									
		}

		if(Practice_tracing.wrong_trace == true){
			AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(con);			
			alertDialogBuilder.setTitle("Failed");
			alertDialogBuilder.setMessage("Wrong Tracing, Please Retry")
			.setPositiveButton("Retry",new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,int id) {
					Intent goToNextActivity = new Intent(getApplicationContext(), Practice_tracing.class);
					finish();
					startActivity(goToNextActivity);
				}
			  });
			AlertDialog alertDialog = alertDialogBuilder.create();
			alertDialog.show();
			return;		
		}					
	}
	
	
	private int avg_score(){
		double score_ = (double) Practice_tracing.user_score;
		double total_score_ = (double) Practice_tracing.total_score;
		double average = (score_ / total_score_) * 100;
		Double avg_score = new Double(average);		
		int my_score = avg_score.intValue();
		return my_score;
	}
	
	private void score_practice(){
		if(Practice_tracing.wrong_trace == true){ 
			return;
		}
		Practice_tracing.tracing_type = "voice";
		Dialog dialog = new Dialog(con);	
		dialog.setContentView(R.layout.scoringdialog);		
		
		int my_score = avg_score();
		
		ImageView draw_star = (ImageView) dialog.findViewById(R.id.draw_star);
		
		if(my_score > 20 && my_score < 40){
			draw_star.setImageResource(R.drawable.star_score_2);	
		}else if(my_score > 39 && my_score < 60){
			draw_star.setImageResource(R.drawable.star_score_3);	
		}else if(my_score > 59 && my_score < 80){
			draw_star.setImageResource(R.drawable.star_score_4);	
		}else if(my_score > 80){
			draw_star.setImageResource(R.drawable.star_score_5);	
		}else{
			draw_star.setImageResource(R.drawable.star_score);	
		}
		
		dialog.setTitle("Your Rating Star");
		dialog.show();		
		dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
		@Override
		public void onDismiss(final DialogInterface arg0) {				
				Intent refresh = new Intent(getApplicationContext(), Practice_tracing.class);
				finish(); 
				startActivity(refresh);
			}
		});
	}
	
	public int tracing_score(){

		Object[] _list_pixel_x = Practice_tracing.list_pixel_x.toArray();
		Object[] _list_pixel_y = Practice_tracing.list_pixel_y.toArray();

		int[] __list_pixel_x = new int[_list_pixel_x.length];
		for(int x = 0; x < _list_pixel_x.length; x++){
			 Double dbl = Double.valueOf(_list_pixel_x[x].toString());
			__list_pixel_x[x] = dbl.intValue();
		}
		
		Arrays.sort(__list_pixel_x);

		int[] ___list_pixel_x = new int[_list_pixel_x.length];
		int minus_pixels = __list_pixel_x[1];
		for(int x = 0; x < _list_pixel_x.length; x++){
			 Double dbl = Double.valueOf(_list_pixel_x[x].toString());
			___list_pixel_x[x] = dbl.intValue() - (minus_pixels + 10);
		}

		int[] ___list_pixel_y = new int[_list_pixel_y.length];	
		for(int x = 0; x < _list_pixel_y.length; x++){
			 Double dbl = Double.valueOf(_list_pixel_y[x].toString());
			___list_pixel_y[x] = dbl.intValue();
		}
		
		HashMap<Integer, Integer> x_map = new HashMap<Integer, Integer>();
		HashMap<Integer, Integer> y_map = new HashMap<Integer, Integer>();
		int count = 0;
		int userscore = 0;
		for(int y = 0; y < 300; y += (300 / 10)){
			for(int x = 0; x < 400; x += (400 / 10)){				
				x_map.put(count, x);	
				y_map.put(count, y);
				count++;
			}
		}		
		for(int x = 0; x < ___list_pixel_x.length; x++){
			boolean hit = false;							
			for(int z = 0; z < num_grid_map.get(Practice_tracing.category_type).length; z++){			
			if((___list_pixel_x[x] + 50 > x_map.get(num_grid_map.get(Practice_tracing.category_type)[z]) 
				&& ___list_pixel_x[x] < x_map.get(num_grid_map.get(Practice_tracing.category_type)[z]) + (400 / 10))){									
					hit = true;
				}

			if((___list_pixel_y[x] + 50 > y_map.get(num_grid_map.get(Practice_tracing.category_type)[z])) 
				&& (___list_pixel_y[x] < y_map.get(num_grid_map.get(Practice_tracing.category_type)[z]) + (300 / 10))){
					hit = true;	
				}			
			}
			if(hit)	{
				userscore++;
			}
		}
		
		int wrong_tracing = 0;		
		for(int x = 0; x < ___list_pixel_x.length; x++){
			boolean hit = false;	
			for(int z = 0; z < wrong_grid_map.get(Practice_tracing.category_type).length; z++){				
				if((___list_pixel_x[x] + 50 > x_map.get(wrong_grid_map.get(Practice_tracing.category_type)[z]) 
				&& ___list_pixel_x[x] < x_map.get(wrong_grid_map.get(Practice_tracing.category_type)[z]) + (400 / 10))){									
					hit = true;
				}

				if((___list_pixel_y[x] + 50 > y_map.get(wrong_grid_map.get(Practice_tracing.category_type)[z])) 
				&& (___list_pixel_y[x] < y_map.get(wrong_grid_map.get(Practice_tracing.category_type)[z]) + (300 / 10))){
					hit = true;
				}		
			}
			if(hit)	{
				wrong_tracing++;
				if(wrong_tracing >= 10){
					userscore--;
					wrong_tracing = 0;
				}
			}
		}
		
		Practice_tracing.tracing_type = "practice";
		double total_score_ = (double) Practice_tracing.total_score;
		double average = (userscore / total_score_) * 100;
		Double percent = new Double(userscore);
		int percent_int = percent.intValue();

		return percent_int;	
	}


	public void score_voice(){		
		if(Practice_tracing.list_pixel_x.size() == 0){
			return;
		}

		Dialog dialog = new Dialog(con);		
		dialog.setContentView(R.layout.scoringdialog);	

		int percent_int = this.tracing_score();

		//stored score database
		db.addScore(user_id, Practice_tracing.category_type.toString(), percent_int);		
		
		ImageView draw_star = (ImageView) dialog.findViewById(R.id.draw_star);
		
		if(percent_int > 20 && percent_int < 40){
			draw_star.setImageResource(R.drawable.star_score_2);	
		}else if(percent_int > 39 && percent_int < 60){
			draw_star.setImageResource(R.drawable.star_score_3);	
		}else if(percent_int > 59 && percent_int < 80){
			draw_star.setImageResource(R.drawable.star_score_4);	
		}else if(percent_int > 80){
			draw_star.setImageResource(R.drawable.star_score_5);	
		}else{
			draw_star.setImageResource(R.drawable.star_score);	
		}	
		dialog.setTitle("Your Rating Star");
	
		dialog.show();		
		dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
		@Override
		public void onDismiss(final DialogInterface arg0) {
				next_diag.show();				
			}
		});		
	}
	
	public void score_mysql(){
		Dialog dialog = new Dialog(con);	
		dialog.setContentView(R.layout.scoringdialog);	
		
		int percent_int = this.tracing_score();
	
		new MysqlScore(con, percent_int).execute(Integer.toString(user_id), 
		Practice_tracing.category_type, Integer.toString(percent_int));										
		
		ImageView draw_star = (ImageView) dialog.findViewById(R.id.draw_star);
		
		if(percent_int > 20 && percent_int < 40){
			draw_star.setImageResource(R.drawable.star_score_2);	
		}else if(percent_int > 39 && percent_int < 60){
			draw_star.setImageResource(R.drawable.star_score_3);	
		}else if(percent_int > 59 && percent_int < 80){
			draw_star.setImageResource(R.drawable.star_score_4);	
		}else if(percent_int > 80){
			draw_star.setImageResource(R.drawable.star_score_5);	
		}else{
			draw_star.setImageResource(R.drawable.star_score);	
		}
				
		dialog.setTitle("Your Rating Star");
		dialog.show();		
		dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
		@Override
		public void onDismiss(final DialogInterface arg0) {
				next_diag.show();				
			}
		});		
	}
	
	
	public void done_tracing(View view){			
			Intent refresh = new Intent(getApplicationContext(), Evaluation.class);
			finish(); 
			startActivity(refresh);
	}
	
	public void prev_tracing(View view){
		Practice_tracing.tracing_type = "practice";			
		Practice_tracing.category_type = letter_map_prev.get(Practice_tracing.category_type);		
		Intent refresh = new Intent(getApplicationContext(), Practice_tracing.class);
		finish(); 
		startActivity(refresh);		
	}
	
	public void next_tracing(View view){		
		Practice_tracing.tracing_type = "practice";
		Practice_tracing.category_type = letter_map_next.get(Practice_tracing.category_type);				
		Intent refresh = new Intent(getApplicationContext(), Practice_tracing.class);
		finish(); 
		startActivity(refresh);		
	}

	public void retry_tracing(View view){									
		Intent refresh = new Intent(getApplicationContext(), Practice_tracing.class);
		finish(); 
		startActivity(refresh);		
	}	
	
class MysqlScore  extends AsyncTask<String,Void, String>{	

		private Context context;		
		private MysqlDB mysql;		
		private int my_score;
		public MysqlScore(Context context, int score) {
			  this.context = context;			
			  this.my_score = score;
		   }
		   
		 protected void onPreExecute()  {
			 mysql = new MysqlDB();			 
		 }
		   
		 protected String doInBackground(String... args)  {
				return mysql.userScore(args[0], args[1], args[2]);
		 }
		 
		  @Override
		   protected void onPostExecute(String data){
										
		   }
		   		  
	}
	
	
}