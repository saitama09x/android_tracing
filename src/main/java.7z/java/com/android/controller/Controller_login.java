package com.android.controller;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.*;
import android.content.Context;
import java.util.ArrayList;
import android.database.Cursor;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import java.util.List; 
import android.widget.Spinner;
import com.android.R;
import com.android.model.*;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;

//Mysql
import android.os.Handler;
import android.os.AsyncTask;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import android.graphics.Typeface;

public class Controller_login extends Activity {
	
	private Db_sqlite db;	
	private Button submit_btn, sign_up_btn;
	private EditText username, password;
	private TextView head_title;
	private Spinner  sel_type, sel_connect;
	private Context con = this;
	private SharedPreferences sharedpreferences;
	public static String loginType = "STUDENT";
	public static String connect_type = "OFFLINE";
	public static int global_user_id = 1;
	private MediaPlayer intro_music;
	private CheckBox online_chk, offline_chk, student_chk, teacher_chk;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		
		db = new Db_sqlite(this);
		/*
		intro_music = MediaPlayer.create(this, R.raw.intro_sound_2);
		intro_music.setVolume(100f, 100f);
		intro_music.setLooping(true);
		intro_music.start();
		*/	
		username = (EditText) findViewById(R.id.username);
		password = (EditText) findViewById(R.id.password);		
		sign_up_btn = (Button) findViewById(R.id.sign_up_btn);
        submit_btn = (Button) findViewById(R.id.login_btn);
		online_chk = (CheckBox) findViewById(R.id.online);
		offline_chk = (CheckBox) findViewById(R.id.offline);
		student_chk = (CheckBox) findViewById(R.id.student);
		teacher_chk = (CheckBox) findViewById(R.id.teacher);


		//sel_type = (Spinner) findViewById(R.id.sel_type);
		//sel_connect = (Spinner) findViewById(R.id.sel_connect);
		/*
		head_title = (TextView) findViewById(R.id.head_title);

		Typeface face = Typeface.createFromAsset(getAssets(), "font/monoalph.ttf");
		head_title.setTypeface(face);
		*/
		List<String> type = new ArrayList<String>();
		type.add("STUDENT");
		type.add("TEACHER");
		
		List<String> connect_online = new ArrayList<String>();
		connect_online.add("ONLINE");
		connect_online.add("OFFLINE");
		/*
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, type);		
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);		
		sel_type.setAdapter(dataAdapter);
		
		ArrayAdapter<String> spinner_connect = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, connect_online);		
		spinner_connect.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);	
		sel_connect.setAdapter(spinner_connect);			
		*/
		
	}

	public void online_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			offline_chk.setChecked(false);	
			Controller_login.connect_type = "ONLINE";		
		}
	}

	public void offline_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			online_chk.setChecked(false);
			Controller_login.connect_type = "OFFLINE";		
		}
	}

	public void student_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			teacher_chk.setChecked(false);
			Controller_login.loginType = "STUDENT";
		}
	}

	public void teacher_chk_click(View v){
		if (((CheckBox) v).isChecked()) {
			student_chk.setChecked(false);
			Controller_login.loginType = "TEACHER";
		}
	}

	public void submit_login(View view){	
	if(Controller_login.connect_type.equals("ONLINE")){
			new MysqlLogin(con).execute(username.getText().toString(), password.getText().toString(), 
			Controller_login.loginType);
	}else{
			Cursor cur = db.getData(username.getText().toString(), password.getText().toString(), Controller_login.loginType);
			int count_row = cur.getCount();
			if(count_row == 1){
				cur.moveToFirst();
				int user_id = cur.getInt(0);
				String fname = cur.getString(1);
				String lname = cur.getString(2);
				String uname = cur.getString(3);				
				AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(con);			
				alertDialogBuilder.setTitle("Welcome " + cur.getString(4));
				Controller_login.global_user_id = user_id;
					if(cur.getString(4).equals("STUDENT")) {
						Controller_login.loginType = cur.getString(4).toString();
						alertDialogBuilder.setMessage(fname + " " + lname + " " + Controller_login.loginType)
						.setPositiveButton("Proceed",new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,int id) {
								//Controller_login.connect_type = "OFFLINE";
								Intent goToNextActivity = new Intent(getApplicationContext(), HomePage.class);
								finish();
								startActivity(goToNextActivity);
							}
						  });
					}else if(cur.getString(4).equals("TEACHER")){
						Controller_login.loginType = cur.getString(4).toString();
						alertDialogBuilder.setMessage(fname + " " + lname)
						.setPositiveButton("Proceed",new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,int id) {
								//Controller_login.connect_type = "OFFLINE";
							 	Intent goToNextActivity = new Intent(getApplicationContext(), Teacher.class);
								finish();
								startActivity(goToNextActivity);
							}
						  });
					
					}
						AlertDialog alertDialog = alertDialogBuilder.create();
						alertDialog.show();
				}else{
					AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(con);			
					alertDialogBuilder.setTitle("Failed");
					alertDialogBuilder.setMessage("Wrong Username and Password");
					AlertDialog alertDialog = alertDialogBuilder.create();
					alertDialog.show();
				}
						
			}		
		
	}
	
	public void sign_up_page(View view){		
		Intent goToNextActivity = new Intent(getApplicationContext(), Controller_sign_up.class);
		finish();
		startActivity(goToNextActivity);		
	}
	
class MysqlLogin  extends AsyncTask<String,Void, String>{	

		private Context context;
		private EditText result;
		private String fname, lname;		
		private MysqlDB mysql;
		
		public MysqlLogin(Context context) {
			  this.context = context;			
		   }
		   
		 protected void onPreExecute()  {
			 mysql = new MysqlDB();	 
		 }
		   
		 protected String doInBackground(String... args)  {
				return mysql.userLogin(args[0], args[1], args[2]);
		 }
		 
		  @Override
		   protected void onPostExecute(String data){
				if(data != ""){	
					try{
						 JSONObject jsonObj = new JSONObject(data);
						 JSONArray res = jsonObj.getJSONArray("result");
						 JSONObject c = res.getJSONObject(0);
						 String fname = c.getString("fname");
						 String lname = c.getString("lname");
						 String id = c.getString("id");
						 Controller_login.global_user_id = Integer.parseInt(id);
						 final String type =  c.getString("type");						
						AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(con);			
						alertDialogBuilder.setTitle("Welcome ");
						alertDialogBuilder.setMessage(fname + " " +  lname)
						.setPositiveButton("Proceed",new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {																	
								if(type .equals("STUDENT")){
									Controller_login.connect_type = "ONLINE";
									Intent goToNextActivity = new Intent(getApplicationContext(), HomePage.class);
									finish();
									startActivity(goToNextActivity);
		
								}else if(type .equals("TEACHER")){
									Controller_login.connect_type = "ONLINE";									
									/* LoginCntrl.loginType = type_;
									Intent goToNextActivity = new Intent(getApplicationContext(), Teacher_page.class);
									finish();
									startActivity(goToNextActivity);	 */									
								}								
							}
						  });					
						AlertDialog alertDialog = alertDialogBuilder.create();
						alertDialog.show();
					}catch(Exception e){

					}				
				}else{
					AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(con);			
					alertDialogBuilder.setTitle("Failed Login");
					alertDialogBuilder.setMessage("Wrong Username and Password");
					AlertDialog alertDialog = alertDialogBuilder.create();
					alertDialog.show();					
				}				
		   }
		   		  
	}
}
