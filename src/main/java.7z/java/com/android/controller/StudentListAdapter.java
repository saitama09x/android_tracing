package com.android.controller;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.content.DialogInterface;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import com.android.R;
import com.android.controller.evaluation.*;

public class StudentListAdapter extends ArrayAdapter<String>{

public final Activity context;
public final String[] name;
public final Integer[] num;
public AlertDialog.Builder alertDialogBuilder;

public StudentListAdapter(Activity context, String[] name, Integer[] num) {
super(context, R.layout.studentlist, name);
this.context = context;
this.name = name;
this.num = num;
this.alertDialogBuilder = new AlertDialog.Builder(context);	
}

@Override
public View getView(int position, View view, ViewGroup parent) {
	LayoutInflater inflater = context.getLayoutInflater();
	View rowView= inflater.inflate(R.layout.studentlist, null, true);
	
	final TextView user = (TextView) rowView.findViewById(R.id.user);
	user.setText(name[position]);
	 
	 /*
	final Button view_btn = (Button) rowView.findViewById(R.id.view_btn);	
	view_btn.setText("View");
	*/

	user.setTag(num[position]);
	user.setOnClickListener(new View.OnClickListener() {
		public void onClick(View view){
				Evaluation.eval_type = "intro";				
				Teacher.student_id = Integer.parseInt(user.getTag().toString());				
				Intent goToNextActivity = new Intent(context.getApplicationContext(), Evaluation.class);
				context.finish();
				context.startActivity(goToNextActivity);
		}
	});
	
	return rowView;
}

}