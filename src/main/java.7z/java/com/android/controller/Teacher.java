package com.android.controller;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.app.Activity;
import android.view.*;
import android.widget.*;
import android.view.View.OnTouchListener;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.List;
import com.android.R;
import android.database.Cursor;
import com.android.model.*;

public class Teacher extends Activity {	
	
	private ListView student_list;
	private Db_sqlite mydb;
	private ArrayList username, userid;
	private TextView teacher_name;
	public static int student_id = 0;
	public int teacher_id = Controller_login.global_user_id;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teachermainpage);
		mydb = new Db_sqlite(this);		
		
		student_list = (ListView) findViewById(R.id.student_list);
		teacher_name = (TextView) findViewById(R.id.teacher_name);

		student_list.setDivider(null);	
		List<AllStudent> array_list = mydb.getAllStudent();	
		Cursor res = mydb.getUser(teacher_id);
		teacher_name.setText("My Teacher");
		int count_row = res.getCount();
		if(count_row == 1){
			res.moveToFirst();
			String fname = res.getString(1);
			String lname = res.getString(2);
			teacher_name.setText(new String(fname + " " + lname));
		}
		username = new ArrayList<String>();
		userid = new ArrayList<Integer>();
		
		for(AllStudent score : array_list){
			userid.add(score.user_id);
			username.add(score.name);
		}
		
		Integer[] user_id_arr = new Integer[userid.size()];
		int count = 0;
		for(Object user_count : userid){
			user_id_arr[count] = (Integer) user_count;
			count++;
		}
		String[] user_name_arr = new String[username.size()];
		int count_1 = 0;
		for(Object user_count : username){
			user_name_arr[count_1] = user_count.toString();
			count_1++;
		}

		
		StudentListAdapter adapter = new StudentListAdapter(this, user_name_arr, user_id_arr);
		student_list.setAdapter(adapter);
		
	}
}